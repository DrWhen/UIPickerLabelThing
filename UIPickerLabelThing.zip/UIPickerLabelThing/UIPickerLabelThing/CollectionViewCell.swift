//
//  CollectionViewCell.swift
//  UIPickerLabelThing
//
//  Created by Christopher Dyer on 01.08.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var label: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
