//
//  TableViewCell.swift
//  UIPickerLabelThing
//
//  Created by Christopher Dyer on 01.08.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

protocol PickerDelegate
{
    func myPickerChangedValue(selectedRowValue: Int?, whichPicker: Int?)
}

class TableViewCell: UITableViewCell
{
    @IBOutlet weak var myCollectionView: UICollectionView!
    @IBOutlet weak var myCollectionViewFlowLayout: UICollectionViewFlowLayout!
    
    var collectionViewLabelTextColumn1 = "Initial text 1"
    var collectionViewLabelTextColumn2 = "Initial text 2"
    var collectionViewLabelTextColumn3 = "Initial text 3"
    var collectionViewLabelTextColumn4 = "Initial text 4"
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        print("in TVC")
        
        self.myCollectionView.dataSource = self as UICollectionViewDataSource
        self.myCollectionView.delegate = self as UICollectionViewDelegate

        self.myCollectionView.register(UINib.init(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
        
        self.myCollectionView.register(UINib.init(nibName: "PickerCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "PickerCollectionViewCell")
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension TableViewCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, PickerDelegate
{
    func myPickerChangedValue(selectedRowValue: Int?, whichPicker: Int?)
        {
            print("which picker - delegate method", whichPicker)
        switch whichPicker
        {
        case 0:
            collectionViewLabelTextColumn1 = "changed col 1)"
        case 2:
            collectionViewLabelTextColumn3 = "changed col 3)"
        case 3:
            collectionViewLabelTextColumn4 = "changed col 4)"
        default:
            collectionViewLabelTextColumn2 = "shouldnT change"
        }
            myCollectionView.reloadData()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    { return 1 }
    
    func collectionView( _ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    { return 8 }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        switch indexPath.item {
        case 0, 2, 3:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PickerCollectionViewCell", for: indexPath) as! PickerCollectionViewCell
            cell.whichPicker = indexPath.item
            cell.reference = self
            return cell
        case 1, 5:
            cell.label.text = "nothing"
        case 4:
            cell.label.text = collectionViewLabelTextColumn1
        case 6:
            cell.label.text = collectionViewLabelTextColumn3
        case 7:
            cell.label.text = collectionViewLabelTextColumn4
        default:
            cell.label.text = "nothing"
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let height = CGFloat(60)
        
        // https://stackoverflow.com/questions/54915227/uicollectionview-remove-space-between-cells-with-7-items-per-row
        var cellWidth = CGFloat()
        var availableWidth = CGFloat(800)
        if collectionView.bounds.size.width < 800
        { availableWidth = collectionView.bounds.size.width }
        let minimumWidth = floor(availableWidth / 4)
        // let remainder = availableWidth - minimumWidth * CGFloat(cellsPerRow4)
        cellWidth = minimumWidth - 1
        
        return CGSize(width: cellWidth, height: height)
    }
}
