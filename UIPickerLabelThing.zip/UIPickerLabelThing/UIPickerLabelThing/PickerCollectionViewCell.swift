//
//  PickerCollectionViewCell.swift
//  UIPickerLabelThing
//
//  Created by Christopher Dyer on 01.08.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class PickerCollectionViewCell: UICollectionViewCell, UIPickerViewDelegate, UIPickerViewDataSource
{
    var reference: PickerDelegate?
    var whichPicker: Int?

    @IBOutlet weak var pickerView: UIPickerView!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        pickerView.delegate = self
        pickerView.dataSource = self
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    { return 1 }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    { return 2 }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView
    {
        
        print("which picker", whichPicker)
        let pickerLabel = UILabel()
        
        switch row {
        case 0:
            pickerLabel.text = "value 1"
        default:
            pickerLabel.text = "value 2"
        }
        
        return pickerLabel
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    { reference?.myPickerChangedValue(selectedRowValue: row, whichPicker: whichPicker) }
}
